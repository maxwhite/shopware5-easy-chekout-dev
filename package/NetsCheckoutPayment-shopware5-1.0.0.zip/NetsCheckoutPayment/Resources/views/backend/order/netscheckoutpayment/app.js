//{block name="backend/order/application"}
// {$smarty.block.parent}
// {include file="backend/order/netscheckoutpayment/controller/nets_controller.js"}
// {include file="backend/order/netscheckoutpayment/store/payment.js"}
// {include file="backend/order/netscheckoutpayment/model/payment.js"}
// {include file="backend/order/netscheckoutpayment/view/detail/window.js"}
// {include file="backend/order/netscheckoutpayment/view/detail/operations_tab.js"}
//{/block}